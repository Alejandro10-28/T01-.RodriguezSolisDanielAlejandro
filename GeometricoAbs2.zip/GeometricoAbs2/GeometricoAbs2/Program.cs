﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeometricoAbs2
{
  public  class Program
    {
        static void Main(string[] args)
        {
            //Se instancia principal para llamar la bienvenida la cual es la que contiene todo los procedimientos
            Principal M = new Principal();
            M.Bienvenida();
        }
    }
}
